package br.com.xadrezvisual;
import android.app.*;import android.content.*;import android.content.pm.ServiceInfo;import android.content.res.Configuration;import android.graphics.*;import android.hardware.display.*;import android.media.*;import android.media.projection.*;import android.os.*;import android.view.*;import android.widget.*;import java.nio.*;import java.util.concurrent.*;
public class CaptureService extends Service {
 final Handler main=new Handler(Looper.getMainLooper());final ExecutorService worker=Executors.newSingleThreadExecutor();WindowManager wm;MediaProjection projection;ImageReader reader;VirtualDisplay display;Engine engine;Vision vision;android.content.SharedPreferences prefs;
 LinearLayout panel;TextView status;View selector;Ring ringA,ringB;WindowManager.LayoutParams panelParams;Rect region;Board board;boolean whiteBottom;volatile boolean active=false,stopped=false;boolean busy=false,selecting=false;int width,height,density,percent,stable=0;volatile int generation=0;String last="",suggestion="",analyzed="",rejected="";long retryAt=0;boolean calibrated=false;boolean compact=false;boolean detectingSide=false;int expandedWidth=0;
 final Runnable tick=new Runnable(){public void run(){if(stopped)return;if(active&&!busy&&!selecting&&region!=null){hideRings();busy=true;final int gen=generation;main.postDelayed(()->{if(stopped)return;worker.execute(()->processFrame(gen));},90);}main.postDelayed(this,400);}};
 @Override public IBinder onBind(Intent i){return null;}
 @Override public int onStartCommand(Intent intent,int flags,int id){if(intent!=null&&"STOP".equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}if(projection!=null){whiteBottom=prefs.getBoolean("white",true);percent=prefs.getInt("percent",80);generation++;active=false;hideRings();analyzed="";suggestion="";setStatus("Configuração atualizada. Nova ou ▶ para continuar.");return START_NOT_STICKY;}
  prefs=getSharedPreferences("chess",0);wm=getSystemService(WindowManager.class);whiteBottom=prefs.getBoolean("white",true);percent=prefs.getInt("percent",80);
  NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel("capture","Captura autorizada",NotificationManager.IMPORTANCE_LOW));PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,CaptureService.class).setAction("STOP"),PendingIntent.FLAG_IMMUTABLE);PendingIntent open=PendingIntent.getActivity(this,2,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE);
  Notification n=new Notification.Builder(this,"capture").setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("Xadrez Visual: captura ativa").setContentText("Análise local. Toque em Parar para encerrar.").setContentIntent(open).addAction(new Notification.Action.Builder(null,"Parar",stop).build()).setOngoing(true).build();startForeground(1,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
  try{if(intent==null||!intent.hasExtra("data"))throw new IllegalStateException("Autorize a captura novamente");android.util.DisplayMetrics metrics=new android.util.DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(metrics);width=metrics.widthPixels;height=metrics.heightPixels;density=metrics.densityDpi;
   try{board=new Board(prefs.getString("fen",Board.INITIAL));}catch(Exception e){board=new Board(Board.INITIAL);}
   reader=ImageReader.newInstance(width,height,PixelFormat.RGBA_8888,3);
   MediaProjectionManager manager=getSystemService(MediaProjectionManager.class);projection=manager.getMediaProjection(intent.getIntExtra("code",-1),intent.getParcelableExtra("data"));
   projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){setStatus("Captura encerrada pelo Android. Abra o app para iniciar novamente.");stopSelf();}@Override public void onCapturedContentResize(int w,int h){if(w!=width||h!=height){setStatus("Tamanho da tela mudou. Inicie a captura novamente.");stopSelf();}}},main);
   display=projection.createVirtualDisplay("XadrezVisual",width,height,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,main);
   makePanel();vision=new Vision(this);if(prefs.getInt("screenW",0)==width&&prefs.getInt("screenH",0)==height){int l=prefs.getInt("left",0),t=prefs.getInt("top",0),s=prefs.getInt("size",0);if(s>=160&&l>=0&&t>=0&&l+s<=width&&t+s<=height)region=new Rect(l,t,l+s,t+s);}
   setStatus("Abra uma partida de treino • Área seleciona o tabuleiro • Nova partida detecta a cor inferior");main.post(tick);
  }catch(Exception e){setStatus("Não iniciou: "+e.getMessage());stopSelf();}return START_NOT_STICKY;
 }
 int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 WindowManager.LayoutParams params(int w,int h,boolean touches){WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN|(touches?0:WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP|Gravity.LEFT;p.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;if(!touches)p.alpha=.65f;return p;}
 void makePanel(){panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(5),dp(3),dp(5),dp(3));panel.setBackgroundColor(Color.rgb(15,43,59));status=new TextView(this);status.setTextColor(Color.WHITE);status.setTextSize(12);status.setMaxLines(3);panel.addView(status);LinearLayout row=new LinearLayout(this);panel.addView(row);button(row,"Área",this::selectArea);button(row,"Nova partida",()->{if(region==null){setStatus("Selecione Área primeiro");return;}newGame();});button(row,"▶/Ⅱ",()->{active=!active;generation++;stable=0;last="";analyzed="";suggestion="";rejected="";hideRings();setStatus(active?"Retomando posição salva…":"Pausado");});LinearLayout row2=new LinearLayout(this);panel.addView(row2);button(row2,"Minimizar / expandir",this::toggleCompact);button(row2,"Fechar painel",this::stopSelf);
  panelParams=params(Math.min(width-dp(16),dp(360)),WindowManager.LayoutParams.WRAP_CONTENT,true);panelParams.x=dp(8);panelParams.y=dp(80);expandedWidth=panelParams.width;wm.addView(panel,panelParams);
  status.setOnTouchListener(new View.OnTouchListener(){float x,y;int px,py;boolean moved;public boolean onTouch(View v,android.view.MotionEvent e){if(e.getAction()==0){x=e.getRawX();y=e.getRawY();px=panelParams.x;py=panelParams.y;moved=false;return true;}else if(e.getAction()==2){float dx=e.getRawX()-x,dy=e.getRawY()-y;if(Math.abs(dx)>dp(4)||Math.abs(dy)>dp(4))moved=true;panelParams.x=Math.max(0,Math.min(width-panel.getWidth(),px+Math.round(dx)));panelParams.y=Math.max(0,Math.min(height-panel.getHeight(),py+Math.round(dy)));wm.updateViewLayout(panel,panelParams);return true;}else if(e.getAction()==1){if(!moved&&compact)toggleCompact();return true;}return true;}});
 }
 void toggleCompact(){
  if(panel==null||panelParams==null)return;
  compact=!compact;
  if(compact){
   status.setText("XV • "+(active?"CAPTURA ATIVA":"PAUSADO")+"  ·  toque ↗");
   for(int i=1;i<panel.getChildCount();i++)panel.getChildAt(i).setVisibility(View.GONE);
   panelParams.width=dp(150);
   status.setMaxLines(1);
   status.setTextSize(11);
  }else{
   for(int i=1;i<panel.getChildCount();i++)panel.getChildAt(i).setVisibility(View.VISIBLE);
   panelParams.width=expandedWidth>0?expandedWidth:Math.min(width-dp(16),dp(360));
   status.setMaxLines(3);
   status.setTextSize(12);
   setStatus(active?"Captura ativa":"Pausado");
  }
  wm.updateViewLayout(panel,panelParams);
 }
 void button(LinearLayout row,String title,Runnable r){Button b=new Button(this);b.setText(title);b.setTextSize(12);b.setMinWidth(0);b.setMinimumWidth(0);row.addView(b,new LinearLayout.LayoutParams(0,dp(44),1));b.setOnClickListener(v->r.run());}
 void newGame(){generation++;board=new Board(Board.INITIAL);calibrated=false;detectingSide=true;last="";stable=0;analyzed="";suggestion="";rejected="";active=true;hideRings();setStatus("Nova partida: identificando automaticamente brancas/pretas na parte inferior…");}
 void selectArea(){active=false;generation++;hideRings();if(selecting)return;selecting=true;panel.setVisibility(View.GONE);selector=new View(this){Paint p=new Paint(3);float x=-1,y=-1;@Override protected void onDraw(Canvas c){c.drawColor(0x44000000);p.setColor(Color.WHITE);p.setTextSize(dp(18));c.drawText(x<0?"Toque no canto SUPERIOR ESQUERDO":"Toque no canto INFERIOR DIREITO",dp(16),dp(100),p);if(x>=0){p.setColor(Color.GREEN);c.drawCircle(x,y,dp(6),p);}}@Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;if(x<0){x=e.getX();y=e.getY();invalidate();return true;}int l=Math.round(x),t=Math.round(y),w=Math.round(e.getX()-x),h=Math.round(e.getY()-y);if(w<160||h<160||Math.abs(w-h)>Math.max(w,h)*.08||l<0||t<0){x=-1;invalidate();return true;}int s=Math.min(w,h);region=new Rect(l,t,l+s,t+s);prefs.edit().putInt("left",l).putInt("top",t).putInt("size",s).putInt("screenW",width).putInt("screenH",height).apply();wm.removeView(this);selector=null;selecting=false;panel.setVisibility(View.VISIBLE);setStatus("Área salva. Toque em Nova partida no início da próxima partida.");return true;}};wm.addView(selector,params(width,height,true));}
 void processFrame(int gen){Bitmap image=null;String message="",move="";Board next=board;boolean save=false;try{
   if(stopped||gen!=generation||!active)return;
   Image frame=reader.acquireLatestImage();if(frame==null){message="Aguardando imagem da tela…";return;}
   try{Image.Plane plane=frame.getPlanes()[0];int stride=plane.getPixelStride(),row=plane.getRowStride();if(stride!=4)throw new IllegalStateException("Formato de captura incompatível");Bitmap padded=Bitmap.createBitmap(row/stride,height,Bitmap.Config.ARGB_8888);padded.copyPixelsFromBuffer(plane.getBuffer());image=Bitmap.createBitmap(padded,0,0,width,height);if(padded!=image)padded.recycle();}finally{frame.close();}
   if(region==null||region.right>image.getWidth()||region.bottom>image.getHeight())throw new IllegalStateException("Selecione Área novamente");
   // The floating controls must stay outside the chessboard.
   Rect controls=new Rect(panelParams.x,panelParams.y,panelParams.x+panel.getWidth(),panelParams.y+panel.getHeight());if(Rect.intersects(region,controls)){message="Arraste o painel para FORA do tabuleiro";return;}
   if(detectingSide){
    String asWhiteBottom=vision.read(image,region,true);
    String asBlackBottom=vision.read(image,region,false);
    String initial=new Board(Board.INITIAL).labels();
    boolean whiteMatch=initial.equals(asWhiteBottom);
    boolean blackMatch=initial.equals(asBlackBottom);
    if(whiteMatch==blackMatch){message="Não consegui confirmar a cor. Deixe a posição inicial totalmente visível e toque em Nova partida novamente.";return;}
    whiteBottom=whiteMatch;
    prefs.edit().putBoolean("white",whiteBottom).apply();
    detectingSide=false;
    last="";stable=0;
    message="Cor detectada automaticamente: "+(whiteBottom?"brancas":"pretas")+" embaixo.";
   }
   String observed=vision.read(image,region,whiteBottom);if(observed.equals(last))stable++;else{last=observed;stable=1;}
   if(observed.contains("?")||stable<2){message=observed.contains("?")?"Leitura incerta: confira área, tema e peças cobertas":"Aguardando peças pararem…";return;}
   if(!observed.equals(board.labels())){String key=board.fen()+observed;if(!key.equals(rejected))next=board.recover(observed);else next=null;if(next==null){rejected=key;message="Posição diferente. Confira cor/área; retome por FEN se perdeu vários lances.";return;}rejected="";}
   save=true;
   if(next.legal().isEmpty()){message=next.inCheck(next.white)?"Xeque-mate • Nova para outra partida":"Empate por afogamento • Nova para outra partida";return;}
   if(next.white!=whiteBottom){message="Vez do adversário";return;}
   if(!next.fen().equals(analyzed)||suggestion.isEmpty()){
    if(System.currentTimeMillis()<retryAt){message="Motor reiniciando…";return;}
    if(engine==null)engine=new Engine(getApplicationInfo().nativeLibraryDir+"/libstockfish.so");
    move=engine.best(next,percent);
   }else move=suggestion;
   message=move.length()>4?"Sua vez • promoção: "+move.substring(4).toUpperCase():"Sua vez • siga os círculos verdes";
  }catch(Exception e){message="Falha: "+e.getMessage()+" • tentando novamente";retryAt=System.currentTimeMillis()+2000;if(engine!=null){engine.close();engine=null;}}
  finally{if(image!=null)image.recycle();final String msg=message,chosen=move;final Board result=next;final boolean persist=save;main.post(()->{busy=false;if(stopped||gen!=generation||!active)return;if(persist&&result!=null){board=result;calibrated=true;prefs.edit().putString("fen",board.fen()).apply();}suggestion=chosen;analyzed=chosen.isEmpty()?"":board.fen();setStatus(msg);if(!chosen.isEmpty())drawMove(chosen);else hideRings();});}
 }
 void setStatus(String msg){if(prefs!=null)prefs.edit().putString("status",msg).apply();if(status!=null)status.setText(msg);}
 void hideRings(){if(ringA!=null)ringA.setVisibility(View.INVISIBLE);if(ringB!=null)ringB.setVisibility(View.INVISIBLE);}
 void drawMove(String move){if(region==null||move.length()<4)return;if(ringA==null){ringA=new Ring();ringB=new Ring();wm.addView(ringA,params(1,1,false));wm.addView(ringB,params(1,1,false));}place(ringA,Board.index(move.substring(0,2)));place(ringB,Board.index(move.substring(2,4)));}
 void place(Ring ring,int square){int i=whiteBottom?square:63-square;float cell=region.width()/8f;int size=Math.round(cell*.86f);WindowManager.LayoutParams p=params(size,size,false);p.x=Math.round(region.left+(i%8+.5f)*cell-size/2f);p.y=Math.round(region.top+(i/8+.5f)*cell-size/2f);wm.updateViewLayout(ring,p);ring.setVisibility(View.VISIBLE);}
 class Ring extends View{Paint p=new Paint(3);Ring(){super(CaptureService.this);}@Override protected void onDraw(Canvas c){p.setColor(Color.rgb(30,255,80));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(3));c.drawCircle(getWidth()/2f,getHeight()/2f,Math.min(getWidth(),getHeight())/2f-dp(4),p);}}
 @Override public void onConfigurationChanged(Configuration c){super.onConfigurationChanged(c);if(prefs!=null){setStatus("Tela girada. Inicie a captura novamente e selecione Área.");stopSelf();}}
 @Override public void onDestroy(){stopped=true;active=false;generation++;main.removeCallbacksAndMessages(null);if(engine!=null)engine.close();worker.shutdownNow();if(display!=null)display.release();if(reader!=null)reader.close();if(projection!=null){projection.stop();projection=null;}for(View v:new View[]{selector,ringA,ringB,panel})if(v!=null)try{wm.removeView(v);}catch(Exception ignored){}stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
}
