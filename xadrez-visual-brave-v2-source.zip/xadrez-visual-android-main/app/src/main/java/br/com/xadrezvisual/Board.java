package br.com.xadrezvisual;
import java.util.*;
/** Orthodox chess. Array order a8..h1; immutable successors. */
public final class Board {
 public char[] squares; public boolean white; public String rights; public int ep, half, full;
 public static final String INITIAL="rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
 public record Move(int from,int to,char promotion) {
  public String uci(){return name(from)+name(to)+(promotion==0?"":String.valueOf(promotion));}
 }
 public Board(String fen){
  String[] f=fen.trim().split("\\s+"); if(f.length!=6)throw new IllegalArgumentException("FEN precisa de 6 campos");
  squares=new char[64];Arrays.fill(squares,'.');int i=0;
  for(char c:f[0].toCharArray()){if(c=='/')continue;if(c>='1'&&c<='8')i+=c-'0';else {if(i>=64||"pnbrqkPNBRQK".indexOf(c)<0)throw new IllegalArgumentException("FEN inválida");squares[i++]=c;}}
  if(i!=64 || !f[1].matches("[wb]"))throw new IllegalArgumentException("FEN inválida");
  white=f[1].equals("w");rights=f[2];ep=f[3].equals("-")?-1:index(f[3]);half=Integer.parseInt(f[4]);full=Integer.parseInt(f[5]);
  if(new String(squares).chars().filter(c->c=='K').count()!=1||new String(squares).chars().filter(c->c=='k').count()!=1)throw new IllegalArgumentException("Reis ausentes");
 }
 private Board(Board b){squares=b.squares.clone();white=b.white;rights=b.rights;ep=b.ep;half=b.half;full=b.full;}
 public static int index(String s){return (8-(s.charAt(1)-'0'))*8+s.charAt(0)-'a';}
 public static String name(int i){return ""+(char)('a'+i%8)+(8-i/8);}
 static boolean color(char c){return Character.isUpperCase(c);}
 public String labels(){return new String(squares);}
 public String fen(){StringBuilder s=new StringBuilder();for(int r=0;r<8;r++){int n=0;for(int c=0;c<8;c++){char p=squares[r*8+c];if(p=='.')n++;else{if(n>0)s.append(n);n=0;s.append(p);}}if(n>0)s.append(n);if(r<7)s.append('/');}return s+" "+(white?"w":"b")+" "+(rights.isEmpty()?"-":rights)+" "+(ep<0?"-":name(ep))+" "+half+" "+full;}
 public Board play(Move m){Board b=new Board(this);char p=b.squares[m.from],captured=b.squares[m.to];b.squares[m.from]='.';b.squares[m.to]=m.promotion==0?p:(white?Character.toUpperCase(m.promotion):m.promotion);
  if(Character.toLowerCase(p)=='p'&&m.to==ep&&captured=='.')b.squares[m.to+(white?8:-8)]='.';
  if(Character.toLowerCase(p)=='k'&&Math.abs(m.to-m.from)==2){int rf=m.to>m.from?m.from+3:m.from-4;int rt=m.to>m.from?m.from+1:m.from-1;b.squares[rt]=b.squares[rf];b.squares[rf]='.';}
  if(p=='K')b.rights=b.rights.replace("K","").replace("Q","");if(p=='k')b.rights=b.rights.replace("k","").replace("q","");
  int[] homes={63,56,7,0};String[] rs={"K","Q","k","q"};for(int j=0;j<4;j++)if(m.from==homes[j]||m.to==homes[j])b.rights=b.rights.replace(rs[j],"");
  b.ep=Character.toLowerCase(p)=='p'&&Math.abs(m.to-m.from)==16?(m.to+m.from)/2:-1;b.half=(Character.toLowerCase(p)=='p'||captured!='.')?0:half+1;b.full=full+(white?0:1);b.white=!white;return b;
 }
 public boolean attacked(int at,boolean byWhite){int r=at/8,c=at%8;
  for(int i=0;i<64;i++){char p=squares[i];if(p=='.'||color(p)!=byWhite)continue;int dr=r-i/8,dc=c-i%8;char k=Character.toLowerCase(p);int ar=Math.abs(dr),ac=Math.abs(dc);
   if(k=='p'&&dr==(byWhite?-1:1)&&ac==1)return true;if(k=='n'&&ar*ac==2)return true;if(k=='k'&&Math.max(ar,ac)==1)return true;
   if((k=='b'&&ar==ac&&ar>0)||(k=='r'&&((dr==0)^(dc==0)))||(k=='q'&&((ar==ac&&ar>0)||((dr==0)^(dc==0))))){int sr=Integer.signum(dr),sc=Integer.signum(dc),rr=i/8+sr,cc=i%8+sc;boolean clear=true;while(rr!=r||cc!=c){if(squares[rr*8+cc]!='.'){clear=false;break;}rr+=sr;cc+=sc;}if(clear)return true;}
  }return false;
 }
 public boolean inCheck(boolean w){for(int i=0;i<64;i++)if(squares[i]==(w?'K':'k'))return attacked(i,!w);return true;}
 private void add(List<Move> a,int f,int t){if(Character.toLowerCase(squares[f])=='p'&&(t/8==0||t/8==7)){for(char p:new char[]{'q','r','b','n'})a.add(new Move(f,t,p));}else a.add(new Move(f,t,(char)0));}
 public List<Move> legal(){List<Move> a=new ArrayList<>();for(int i=0;i<64;i++){char p=squares[i];if(p=='.'||color(p)!=white)continue;int r=i/8,c=i%8;char k=Character.toLowerCase(p);
  if(k=='p'){int nr=r+(white?-1:1);if(nr<0||nr>7)continue;int t=nr*8+c;if(squares[t]=='.'){add(a,i,t);if(r==(white?6:1)&&squares[i+(white?-16:16)]=='.')add(a,i,i+(white?-16:16));}for(int dc:new int[]{-1,1})if(c+dc>=0&&c+dc<8){t=nr*8+c+dc;char q=squares[t];if((q!='.'&&color(q)!=white&&Character.toLowerCase(q)!='k')||(t==ep&&squares[t+(white?8:-8)]==(white?'p':'P')))add(a,i,t);}continue;}
  int[][] dirs=k=='n'?new int[][]{{-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}}:new int[][]{{-1,-1},{-1,0},{-1,1},{0,-1},{0,1},{1,-1},{1,0},{1,1}};
  for(int[] d:dirs){if(k=='b'&&(d[0]==0||d[1]==0))continue;if(k=='r'&&d[0]!=0&&d[1]!=0)continue;int rr=r+d[0],cc=c+d[1];while(rr>=0&&rr<8&&cc>=0&&cc<8){int t=rr*8+cc;char q=squares[t];if(q!='.'&&color(q)==white)break;if(Character.toLowerCase(q)=='k')break;add(a,i,t);if(q!='.'||k=='n'||k=='k')break;rr+=d[0];cc+=d[1];}}
  if(k=='k'&&i==(white?60:4)&&!inCheck(white)){String ks=white?"K":"k",qs=white?"Q":"q";char rook=white?'R':'r';if(rights.contains(ks)&&squares[i+3]==rook&&squares[i+1]=='.'&&squares[i+2]=='.'&&!attacked(i+1,!white)&&!attacked(i+2,!white))add(a,i,i+2);if(rights.contains(qs)&&squares[i-4]==rook&&squares[i-1]=='.'&&squares[i-2]=='.'&&squares[i-3]=='.'&&!attacked(i-1,!white)&&!attacked(i-2,!white))add(a,i,i-2);}
 }List<Move> out=new ArrayList<>();for(Move m:a)if(!play(m).inCheck(white))out.add(m);return out;}
 public Board recover(String observed){if(observed.indexOf('?')>=0)return null;if(labels().equals(observed))return this;Board found=null;for(Move m:legal()){Board one=play(m);if(one.labels().equals(observed)){if(found!=null)return null;found=one;}for(Move n:one.legal()){Board two=one.play(n);if(two.labels().equals(observed)){if(found!=null)return null;found=two;}}}return found;}
}
