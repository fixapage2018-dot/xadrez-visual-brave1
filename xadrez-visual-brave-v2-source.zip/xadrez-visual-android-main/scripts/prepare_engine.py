#!/usr/bin/env python3
"""Fetch an exact upstream Stockfish release; verify bytes before unpacking."""
import hashlib, pathlib, urllib.request, tarfile, tempfile, shutil
ROOT=pathlib.Path(__file__).resolve().parents[1]
URL='https://github.com/official-stockfish/Stockfish/releases/download/sf_17.1/stockfish-android-armv8.tar'
SHA='634d8e7af7f776e641d909b49fa52e7f88e8ec3f18c0535ee63d564bf246ebcd'
with tempfile.TemporaryDirectory() as tmp:
    archive=pathlib.Path(tmp)/'engine.tar'
    urllib.request.urlretrieve(URL, archive)
    if hashlib.sha256(archive.read_bytes()).hexdigest()!=SHA: raise RuntimeError('SHA-256 inesperado; não usar este download')
    with tarfile.open(archive) as t:
        binary=t.extractfile('stockfish/stockfish-android-armv8')
        target=ROOT/'app/src/main/jniLibs/arm64-v8a/libstockfish.so'
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(binary.read())
        # Preserve corresponding source and licensing alongside the binary.
        for member in t.getmembers():
            if member.isfile() and (member.name.startswith('stockfish/src/') or member.name.startswith('stockfish/scripts/') or member.name in ['stockfish/Copying.txt','stockfish/AUTHORS','stockfish/README.md']):
                rel=pathlib.PurePosixPath(member.name).relative_to('stockfish')
                if '..' in rel.parts: raise RuntimeError('Caminho inválido no pacote')
                out=ROOT/'stockfish-source'/rel
                out.parent.mkdir(parents=True,exist_ok=True)
                out.write_bytes(t.extractfile(member).read())
print('Stockfish 17.1 ARM64 verificado e preparado.')
