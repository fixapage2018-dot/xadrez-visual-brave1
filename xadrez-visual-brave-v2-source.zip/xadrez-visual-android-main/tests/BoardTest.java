import br.com.xadrezvisual.Board;
public class BoardTest {
 static long perft(Board b,int depth){if(depth==0)return 1;long n=0;for(Board.Move m:b.legal())n+=perft(b.play(m),depth-1);return n;}
 static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
 public static void main(String[] args){Board initial=new Board(Board.INITIAL);check(perft(initial,1)==20,"initial depth 1");check(perft(initial,2)==400,"initial depth 2");check(perft(initial,3)==8902,"initial depth 3");check(perft(initial,4)==197281,"initial depth 4");
 Board kiwi=new Board("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1");check(perft(kiwi,1)==48,"kiwipete depth1");check(perft(kiwi,2)==2039,"kiwipete depth2");check(perft(kiwi,3)==97862,"kiwipete depth3");
 Board end=new Board("8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1");check(perft(end,3)==2812,"en passant test");
 for(Board.Move m:initial.legal()){Board one=initial.play(m);Board recovered=initial.recover(one.labels());check(recovered!=null&&recovered.fen().equals(one.fen()),"recover any first move");}
 Board after=initial.play(new Board.Move(52,36,(char)0)).play(new Board.Move(6,21,(char)0));check(initial.recover(after.labels()).fen().equals(after.fen()),"recover two plies");check(initial.recover("?".repeat(64))==null,"uncertainty");check(initial.fen().equals(Board.INITIAL),"immutable");Board promo=new Board("4k3/P7/8/8/8/8/8/4K3 w - - 0 1");check(promo.legal().stream().filter(m->m.from()==8&&m.to()==0).count()==4,"all promotion choices");
 Board castle=new Board("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1");check(castle.legal().stream().filter(m->m.from()==60&&Math.abs(m.to()-m.from())==2).count()==2,"both castles");
 check(castle.play(new Board.Move(60,62,(char)0)).squares[61]=='R',"castling moves rook");System.out.println("PASS: perft initial/kiwipete/en-passant, arbitrary first moves, 2 plies, uncertainty, immutability");
 }
}
